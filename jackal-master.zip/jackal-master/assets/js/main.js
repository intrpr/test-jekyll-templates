(function () {
    'use strict';

    // Your additional js should go there

}());
