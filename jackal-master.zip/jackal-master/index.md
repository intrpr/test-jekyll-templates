---
layout: default
---

<div class="lead pretty-links">
  Hi! this is just a sample **intro text**. You would normally put your [full name](about/) here and say something *smart* about yourself.

  This could also be the good place to say were you are coming from, what you [do for a living](work/) and maybe what you are [interested in](projects/). You might also be [writing](articles/) about stuff.

  But after all this is your site and I'm just a **placeholder text** so what would i know about some *home page content*.
</div>
