---
layout: post
title: Cognitive Workload and Search Simplicity
tags: On Design
---
