---
layout: post
title: Pareto's Principle in Web Design
tags: On Design
---
